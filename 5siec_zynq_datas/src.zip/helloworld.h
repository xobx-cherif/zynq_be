/*
 * helloworld.h
 *
 *  Created on: Nov 28, 2017
 *      Author: xobx
 */

#ifndef HELLOWORLD_H_
#define HELLOWORLD_H_

/* ---------------------------------------------------------------------------- *
* Header Files									*
* ----------------------------------------------------------------------------- */
#include <stdio.h>
#include <xil_io.h>
#include <sleep.h>
#include "xiicps.h"
#include <xil_printf.h>
#include <xparameters.h>
#include "stdlib.h"
//#include "xgpio.h"
//#include "xuartps.h"

/* ---------------------------------------------------------------------------- *
 * Custom IP Header Files							*
 * ---------------------------------------------------------------------------- */
#include "audio.h"
//#include "axi_overdrive.h"

/* ---------------------------------------------------------------------------- *
 * Prototype Functions							        *
 * ---------------------------------------------------------------------------- */
//void menu();

//void audio_stream();
//void audio_disto();

/* ---------------------------------------------------------------------------- *
 *Redefinitions from xparameters.h 						*
 * ---------------------------------------------------------------------------- */

//#define UART_BASEADDR XPAR_PS7_UART_1_BASEADDR

//#define LED_BASE XPAR_LED_CONTROLLER_0_S00_AXI_BASEADDR
//#define AUDIO_ENABLE_ID XPAR_AXI_GPIO_0_DEVICE_ID



/* ---------------------------------------------------------------------------- *
 * 							Global Variables									*
 * ---------------------------------------------------------------------------- */
XIicPs Iic; //I2c instance for audio codec config


#endif /* HELLOWORLD_H_ */
